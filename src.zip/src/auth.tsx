import axios from "axios";

const baseurl="http://localhost/snigdh_ci4/api/"

const loginUser =(data:object)=>{
    return axios.post<any>(baseurl+'login',data)
}
const addProductToDB =(data:any)=>{
    return axios.post<any>(baseurl+'addProduct',data)
}
const addCategoryToDB =(data:any)=>{
    return axios.post<any>(baseurl+'addCategory',data)
}
const updateProductToDB =(data:any,id:any)=>{
    return axios.post<any>(baseurl+'updateProduct',data,{headers:{'id': id}})
}
const updateCatecoryToDB =(data:any,id:any)=>{
    return axios.post<any>(baseurl+'updateCategory',data,{headers:{'id': id}})
}
const getCategory =()=>{
    return axios.post<any>(baseurl+'getCategory')
}
const getProduct =()=>{
    return axios.post<any>(baseurl+'getProduct')
}
const deleteProductfromDB =(id:number)=>{

    return axios.delete<any>(baseurl+`deleteProduct/${id}`);
}
const deleteCategoryfromDB =(id:number)=>{

    return axios.delete<any>(baseurl+`deleteCategory/${id}`)
}

export {loginUser,addProductToDB,addCategoryToDB,getProduct,getCategory,deleteProductfromDB,deleteCategoryfromDB,updateProductToDB,updateCatecoryToDB};