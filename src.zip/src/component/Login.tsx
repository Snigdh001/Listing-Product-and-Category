import React from 'react'
import './css/Login.css'
import '../../node_modules/bootstrap/dist/css/bootstrap.min.css'
import { loginUser } from '../auth'
import { Navigate, useNavigate } from 'react-router-dom'

const Login = () => {
  const navigate = useNavigate();
  const login = async (e: any) => {
    e.preventDefault()
    
    const formdata = new FormData(e.currentTarget)
     const data ={
      email:formdata.get('email'),
      password:formdata.get('password'),
    }
    const result = await loginUser(data)
    console.warn(result)
    if(result.data.messages.success==="true")
                {
                    // console.log(result.data);
                    let session ={
                        id:result.data.messages.id as string,
                    }
                    
                    
                    localStorage.setItem("Session",JSON.stringify(session));
                        alert("Logged In Successfully! : )");
                        navigate('/user');

                }
                else{
                    alert("Invalid Data / Login Failed : (");
                }

  }
  return (
    <div className='body'>
      <div className="container m-2 p-2" style={{ backgroundColor:'yellowgreen',borderRadius:"10px",  width: "25rem", height:"30rem" }}>
        <label htmlFor="Login" style={{}}>Login</label>
        <form action="" onSubmit={login} method="post">
          <div className="inputbody m-2 p-2 ">
            <div className='m-2 p-2'>
              <label htmlFor="Email" className='m-1 p-1'>Email</label>
              <input type="email"className='m-1 p-1' name='email' />
            </div>
            <div>
              <label htmlFor="password" className='m-1 p-1'>Password</label>
              <input type="password" name="password" className='m-1 p-1' id="password" />
            </div>
            <button type="submit" className='btn btn-primary m-2 p-2' style={{width:"150px"}}>Login</button>
          </div>
        </form>
      </div>
      </div>
      )
}

      export default Login