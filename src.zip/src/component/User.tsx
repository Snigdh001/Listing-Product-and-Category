import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';  
import { Link } from 'react-router-dom';
import './css/user.css'
const User = () => {
  return (
    <div>
        <header style={{ position: "relative" }} >
        <div id="carouselExampleCaptions" className="carousel slide" data-bs-ride="carousel">
          <div className="carousel-inner">
            <div className="carousel-item active" style={{ backgroundImage: "url('https://source.unsplash.com/bF2vsubyHcQ/1920x1080')",width:'100%'}}>
              <div className="logo">
              <Link to="/user" className='headerlink' >Home</Link>
              <Link to="/product" className='headerlink' >Product</Link>
                <Link to="/category" className='headerlink'>Category</Link>
              </div>
            </div>
          </div>
        </div>
      </header>
      <div>
    <img style={{height:"90vh",width:"100vw"}} src="https://images.pexels.com/photos/4386366/pexels-photo-4386366.jpeg?auto=compress&cs=tinysrgb&w=1600" alt="" />
    </div>
    </div>
    
  )
}

export default User