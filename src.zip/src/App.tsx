import React from 'react';
import logo from './logo.svg';
import './App.css';
import Login from './component/Login';
import { BrowserRouter, Route, Routes } from "react-router-dom";
import User from './component/User';
import Product from './component/Product';
import Category from './component/Category';

function App() {
  return (
    <div className="App">
        

        <BrowserRouter>
        <Routes>
          <Route path='/' element={<>SNigdh </>}> </Route>
          <Route path="/login" element={<><Login/></>}></Route>
          <Route path="/user" element={<><User/></>}></Route>
          <Route path="/product" element={<><Product/></>}></Route>
          <Route path="/category" element={<><Category/></>}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
